while True:
 print("*********************************************")
 print("* MENU DES OPERATIONS *")
 print("*********************************************")
 print("*** 1. ADDITION")
 print("*** 2. SOUSTRACTION")
 print("*** 3. MULTIPLICATIONN")
 print("*** 4. DIVISION")
 print("*** 5. MODULO")
 print("*** 6. QUITTER LE PROGRAMME")
 op=int(input("choisir une opération : "))

 if op==6:
     break
 a=int(input("entrer un operande1: "))
 b=int(input("entrer un operande2: "))
 if op == 1:
     print(a,"+",b,"=",a+b)
 if op == 2:
     print(a,"-",b,"=",a-b)
 if op == 3:
     print(a,"*",b,"=",a*b)
 if op == 4:
     print(a,"/",b,"=",a/b)
 if op == 5:
     print(a,"%",b,"=",a%b)