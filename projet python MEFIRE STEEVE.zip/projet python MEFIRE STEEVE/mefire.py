

choix = 1
while not choix == 2:
    print("")
    nb = int(input("entrer le nombre en chiffre "))
    nb_unite = ['', 'un', 'deux', 'trois', 'quatre', 'cinq', 'six', 'sept', 'huit', 'neuf']
    nb_dizaine = ['dix', 'onze', 'douze', 'treize', 'quatorze', 'quinze', 'seize', 'dix-sept', 'dix-huit', 'dix-neuf']
    nb_dizaine2 = ['', 'dix', 'vingt', 'trente', 'quarante', 'cinquante', 'soixante', 'soixante', 'quatre-vingt', 'quatre-vingt']
    nb_centaine = ['', 'cent', 'deux cent', 'trois cent', 'quatre cent', 'cinq cent', 'six cent', 'sept cent', 'huit cent', 'neuf cent']

    u = nb % 10
    d = nb % 100 - u
    c = nb % 1000 - u - d

    aux_u = u
    aux_d = d / 10
    aux_c = c / 100

    unite = nb_unite[aux_u]
    dizaine = nb_dizaine[aux_u]
    dizaine2 = nb_dizaine2[int(aux_d)]
    centaine = nb_centaine[int(aux_c)]

    if nb < 100:
        if nb == 0:
            print("zero")
        if aux_d == 0:
            print(unite)
        if aux_d == 1:
            print(dizaine)
        if aux_d > 1:
            if aux_d == 7 or aux_d == 9:
                print(dizaine2, dizaine)
            else:
                print(dizaine2 + "-" + unite)
    elif 100 <= nb < 1000:
        if aux_d == 7 or aux_d == 9:
            print(centaine, dizaine2 + "-" + dizaine)
        else:
            if aux_d == 1:
                print(centaine, dizaine)
            else:
                print(centaine, dizaine2 + "-" + unite)

    print("")
    print("*** 1.ENTRER UN NOMBRE")
    print("*** 2.QUITTER LE PROGRAMME")
    choix = int(input(" choisissez l'action "))
